import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Customer } from './customer';
import { Observable } from 'rxjs';
import { Transaction } from './Transaction';



const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class CustomerService {
  private userUrl = 'http://localhost:7000/';
  customer: Customer;
  private accountNumber;
  constructor(private http: HttpClient) {}
  public getCustomers() {
    return this.http.get<Customer[]>(this.userUrl);
  }


  public createCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(this.userUrl, customer);
  }
  public showBalance(acc): Observable<Customer> {
    return this.http.get<Customer>(this.userUrl + 'balance/' + acc);
  }

  public depositAmount(acc, customer: Customer): Observable<Customer> {
    return this.http.put<Customer>(this.userUrl + 'deposit/' + acc, customer);
  }

  public withdrawAmount(acc, customer: Customer): Observable<Customer> {
    return this.http.put<Customer>(this.userUrl + 'withdraw/' + acc, customer);
  }

  public fundTransfer(senderAccNo, recieverAccNo, customer: Customer): Observable<Customer> {
    return this.http.put<Customer>(this.userUrl + 'transfer/' + senderAccNo + '/' + recieverAccNo, customer);
  }

  getTransactionsByAccountNumber(accountNumber): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(this.userUrl + 'transactions/' + accountNumber );
  }
}
