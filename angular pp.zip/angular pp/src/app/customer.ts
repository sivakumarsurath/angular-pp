export class Customer {
  accountNumber: number;
  firstName: string;
  lastName: string;
  age: number;
  password: string;
  amount: number;

  constructor(firstName: string, lastName: string, age: number, password: string, amount: number) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
    this.password = password;
    this.amount = amount;
  }

}